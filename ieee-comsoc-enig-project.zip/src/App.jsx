import React, { useState } from "react";
import { useGoogleFonts, body } from "./lib/theme";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import MissionVision from "./components/MissionVision";
import Board from "./components/Board";
import Events from "./components/Events";
import Activities from "./components/Activities";
import Projects from "./components/Projects";
import Stats from "./components/Stats";
import News from "./components/News";
import IEEEConnection from "./components/IEEEConnection";
import CTA from "./components/CTA";
import Footer from "./components/Footer";
import IntroSequence from "./components/IntroSequence";

export default function App() {
  useGoogleFonts();
  const [introDone, setIntroDone] = useState(() => {
    try {
      return sessionStorage.getItem("comsoc_intro_done") === "1";
    } catch (e) {
      return false;
    }
  });

  return (
    <div className="min-h-screen bg-white" style={body}>
      <style>{`@keyframes comsoc-blink { 0%, 49% { opacity: 1; } 50%, 100% { opacity: 0; } }`}</style>
      {!introDone && <IntroSequence onDone={() => setIntroDone(true)} />}
      <Navbar />
      <Hero />
      <About />
      <MissionVision />
      <Board />
      <Events />
      <Activities />
      <Projects />
      <Stats />
      <News />
      <IEEEConnection />
      <CTA />
      <Footer />
    </div>
  );
}
