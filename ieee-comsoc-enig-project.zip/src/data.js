import { Radio, Cpu, Users, Lightbulb, Wifi, GraduationCap, FlaskConical, Building2, PartyPopper, Presentation, Trophy, BookOpen, Network } from "lucide-react";

const CONTACT = {
  email: "comsoc-enig@ieee.tn",
  address: "ENIG, Zrig, Gabès, Tunisia",
};

const SOCIAL_LINKS = {
  linkedin: "https://www.linkedin.com/company/comsoc-enig",
  instagram: "https://www.instagram.com/ieee_comsoc_enig",
  facebook: "https://www.facebook.com/profile.php?id=61562567000609",
  github: "", // add the chapter's GitHub org/repo URL when available
};

const NAV_LINKS = [
  { label: "Home", href: "#home" },
  { label: "About", href: "#about" },
  { label: "Board", href: "#board" },
  { label: "Events", href: "#events" },
  { label: "Activities", href: "#activities" },
  { label: "Projects", href: "#projects" },
  { label: "Resources", href: "#news" },
  { label: "Contact", href: "#contact" },
];

const boardMembers = [
  { name: "Ahmed Ben Salah", role: "President", bio: "Leads the chapter's vision, partnerships, and activities.", size: "lg" },
  { name: "Yasmine Trabelsi", role: "Vice President", bio: "Coordinates chapter operations and cross-team initiatives.", size: "md" },
  { name: "Karim Jaziri", role: "Technical Activities Lead", bio: "Designs the technical roadmap: workshops, labs, and research.", size: "md" },
  { name: "Nour Haddad", role: "General Secretary", bio: "Keeps the chapter organized — records, correspondence, and reporting.", size: "sm" },
  { name: "Mohamed Ali Gharbi", role: "Treasurer", bio: "Manages the chapter's budget, sponsorships, and finances.", size: "sm" },
  { name: "Sarra Mejri", role: "Media & Communications", bio: "Shapes how the chapter tells its story, online and off.", size: "md" },
];

const events = [
  { id: "EVENT_01", title: "ComSoc Technical Workshop", type: "TECHNICAL_WORKSHOP", date: "14.10.2026", location: "ENIG, Amphitheater A", desc: "Hands-on session on communication protocols and network fundamentals.", status: "OPEN", interest: 64 },
  { id: "EVENT_02", title: "5G & Beyond", type: "TECH_TALK", date: "28.10.2026", location: "ENIG, Room B12", desc: "A deep dive into next-generation wireless architectures and use cases.", status: "REGISTER_NOW", interest: 89 },
  { id: "EVENT_03", title: "Networking Fundamentals Workshop", type: "TECHNICAL_WORKSHOP", date: "06.11.2026", location: "ENIG Networking Lab", desc: "From OSI layers to real configurations — a practical entry point.", status: "OPEN", interest: 72 },
  { id: "EVENT_04", title: "AI & Telecommunications", type: "TECH_TALK", date: "19.11.2026", location: "ENIG, Amphitheater A", desc: "How machine learning is reshaping network optimization and security.", status: "REGISTER_NOW", interest: 91 },
  { id: "EVENT_05", title: "IoT Innovation Day", type: "HACKATHON", date: "03.12.2026", location: "ENIG Campus", desc: "A day of building connected-device prototypes in small teams.", status: "OPEN", interest: 58 },
  { id: "EVENT_06", title: "Industry Talk: Careers in Telecom", type: "TECH_TALK", date: "15.12.2026", location: "ENIG, Room B12", desc: "Engineers from the telecom sector share their career paths.", status: "CLOSED", interest: 40 },
];

const activities = [
  { icon: Presentation, title: "Workshops" },
  { icon: BookOpen, title: "Technical Talks" },
  { icon: Trophy, title: "Hackathons" },
  { icon: GraduationCap, title: "Training Sessions" },
  { icon: FlaskConical, title: "Research" },
  { icon: Building2, title: "Industry Visits" },
  { icon: Network, title: "Networking Events" },
  { icon: PartyPopper, title: "Social Activities" },
];

const projects = [
  { title: "Smart IoT Network", tags: ["IoT", "MQTT", "Python"], desc: "A low-power sensor mesh for environmental monitoring on campus." },
  { title: "AI-Based Network Monitoring", tags: ["Machine Learning", "Networking"], desc: "Anomaly detection for traffic patterns using lightweight ML models." },
  { title: "5G Simulation", tags: ["5G", "MATLAB"], desc: "A simulation environment for studying 5G radio resource allocation." },
  { title: "Software Defined Networking", tags: ["SDN", "Mininet"], desc: "A programmable network testbed built for chapter research sessions." },
  { title: "Wireless Sensor Network", tags: ["Embedded", "LoRa"], desc: "Long-range, low-power telemetry across a distributed sensor array." },
];

const news = [
  { date: "Sep 2026", category: "Announcement", title: "New board elected for the 2026–2027 term", excerpt: "The chapter welcomes a new board to lead the year's technical and community initiatives." },
  { date: "Aug 2026", category: "Recap", title: "Summer bootcamp wraps with 40+ participants", excerpt: "A two-week intensive on networking fundamentals closed with a student demo day." },
  { date: "Jul 2026", category: "Opportunity", title: "IEEE ComSoc student travel grants open", excerpt: "Applications are open for students presenting at ComSoc-sponsored conferences." },
  { date: "Jun 2026", category: "Achievement", title: "Chapter members place at regional IoT hackathon", excerpt: "A three-student team placed second building a connected agriculture prototype." },
];

const stats = [
  { value: 50, suffix: "+", label: "Members" },
  { value: 10, suffix: "+", label: "Events" },
  { value: 8, suffix: "+", label: "Technical Workshops" },
  { value: 5, suffix: "+", label: "Student Projects" },
];

const aboutCards = [
  { icon: Radio, title: "Communications", desc: "Explore modern telecommunications, wireless systems, 5G/6G, IoT, and networking." },
  { icon: Lightbulb, title: "Innovation", desc: "Encourage students to transform ideas into technical projects and innovative solutions." },
  { icon: Users, title: "Community", desc: "Connect students with professionals, researchers, IEEE members, and fellow technology enthusiasts." },
];

const EVENT_ICONS = [Radio, Wifi, Network, Cpu, Lightbulb, Users];

const INTRO_COMMANDS = [
  { cmd: "$ initializing_comsoc_connection", at: 0, done: 750 },
  { cmd: "> scanning network...", at: 800, done: 1550 },
  { cmd: "> satellite signal detected", at: 1600, done: 2200 },
  { cmd: "> establishing handshake...", at: 2250, done: 3050 },
  { cmd: "> connecting to IEEE ComSoc node", at: 3100, done: 3750 },
  { cmd: "> ENIG chapter node found", at: 3800, done: 4300 },
];

export { NAV_LINKS, boardMembers, events, activities, projects, news, stats, aboutCards, EVENT_ICONS, INTRO_COMMANDS, CONTACT, SOCIAL_LINKS };
