import React from "react";
import { ArrowRight, Wifi } from "lucide-react";
import { Reveal, NetworkBackground } from "./shared";
import { heading, body } from "../lib/theme";

function Hero() {
  return (
    <section
      id="home"
      className="relative overflow-hidden flex items-center pt-32 pb-24"
      style={{ background: "linear-gradient(180deg,#050E22 0%,#0A1F45 55%,#0B2A5E 100%)" }}
    >
      <NetworkBackground opacity={0.4} />
      <div
        className="absolute -top-24 -right-24 w-[520px] h-[520px] rounded-full"
        style={{ background: "radial-gradient(circle, rgba(30,155,240,0.18) 0%, transparent 70%)" }}
      />
      <div className="relative max-w-7xl mx-auto px-6 w-full">
        <Reveal>
          <div
            className="inline-flex items-center gap-2 text-xs font-medium text-sky-300 border border-sky-400/30 rounded-full px-4 py-1.5 mb-8"
            style={{ ...body, background: "rgba(30,155,240,0.08)" }}
          >
            <Wifi size={13} /> IEEE ComSoc &bull; ENIG
          </div>
        </Reveal>

        <Reveal delay={80}>
          <h1
            className="text-white font-extrabold leading-[1.05] tracking-tight text-5xl sm:text-6xl lg:text-7xl max-w-4xl"
            style={heading}
          >
            Connecting ideas.
            <br />
            Building the future.
          </h1>
        </Reveal>

        <Reveal delay={160}>
          <p className="mt-7 text-lg sm:text-xl text-blue-100/90 max-w-2xl" style={body}>
            IEEE Communications Society ENIG Student Branch Chapter
          </p>
        </Reveal>

        <Reveal delay={220}>
          <p className="mt-3 text-blue-200/60 max-w-xl text-[15px]" style={body}>
            Empowering students through communications, networking, research, innovation, and technical collaboration.
          </p>
        </Reveal>

        <Reveal delay={300}>
          <div className="mt-10 flex flex-wrap gap-4">
            <a
              href="#about"
              className="inline-flex items-center gap-2 bg-sky-400 hover:bg-sky-300 text-blue-950 font-semibold px-7 py-3.5 rounded-full transition-all active:scale-95"
              style={body}
            >
              Discover Our Chapter <ArrowRight size={17} />
            </a>
            <a
              href="#events"
              className="inline-flex items-center gap-2 border border-white/25 hover:border-white/50 text-white px-7 py-3.5 rounded-full transition-colors"
              style={body}
            >
              Explore Events
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default Hero;
