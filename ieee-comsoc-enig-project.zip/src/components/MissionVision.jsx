import React from "react";
import { Reveal, NetworkBackground } from "./shared";
import { heading } from "../lib/theme";

function MissionVision() {
  return (
    <section className="relative py-28 overflow-hidden" style={{ background: "#081A3A" }}>
      <NetworkBackground opacity={0.18} />
      <div className="relative max-w-7xl mx-auto px-6 grid md:grid-cols-2 gap-14">
        <Reveal>
          <div className="border-l-2 border-sky-400/60 pl-8">
            <h3 className="text-sky-300 font-semibold text-sm mb-4" style={body}>Our mission</h3>
            <p className="text-2xl sm:text-3xl text-white font-semibold leading-snug" style={heading}>
              To create a dynamic student community where knowledge, innovation, and collaboration
              drive the future of communications and networking.
            </p>
          </div>
        </Reveal>
        <Reveal delay={120}>
          <div className="border-l-2 border-blue-400/40 pl-8">
            <h3 className="text-sky-300 font-semibold text-sm mb-4" style={body}>Our vision</h3>
            <p className="text-2xl sm:text-3xl text-blue-100 font-semibold leading-snug" style={heading}>
              To inspire the next generation of engineers and researchers shaping how the world connects.
            </p>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default MissionVision;
