import React, { useState } from "react";
import { ArrowRight, ArrowUpRight, ChevronRight } from "lucide-react";
import { Reveal, useHorizontalScroll, ScrollArrow, BlinkingCursor } from "./shared";
import { events, EVENT_ICONS } from "../data";
import { heading, mono, display } from "../lib/theme";

function EventVisual({ hovered, icon: Icon, interest }) {
  return (
    <div
      className="relative h-40 overflow-hidden"
      style={{
        background: "linear-gradient(160deg,#0A1A38,#040B1C)",
        backgroundImage:
          "linear-gradient(rgba(94,182,245,0.08) 1px, transparent 1px), linear-gradient(90deg, rgba(94,182,245,0.08) 1px, transparent 1px)",
        backgroundSize: "18px 18px",
      }}
    >
      <div
        className="absolute inset-0 flex items-center justify-center transition-transform duration-500"
        style={{ transform: hovered ? "scale(1.12)" : "scale(1)" }}
      >
        <Icon size={46} strokeWidth={1} style={{ color: "#5EB6F5" }} />
      </div>
      {/* dashed callout, echoing the reference schematic's leader lines */}
      <svg className="absolute inset-0 w-full h-full" viewBox="0 0 320 160" aria-hidden="true">
        <line x1="60" y1="30" x2="110" y2="60" stroke="#38BDF8" strokeWidth="1" strokeDasharray="3 3" opacity="0.35" />
        <line x1="250" y1="120" x2="205" y2="95" stroke="#38BDF8" strokeWidth="1" strokeDasharray="3 3" opacity="0.35" />
      </svg>

      {/* telemetry readout, echoing the reference dashboard's labeled bar meters */}
      <div
        className="absolute top-3 left-3 px-2.5 py-1.5 rounded"
        style={{ background: "rgba(4,11,28,0.75)", border: "1px solid rgba(94,182,245,0.25)" }}
      >
        <p className="text-[9px] tracking-wide mb-1" style={{ ...mono, color: "#7C93B4" }}>INTEREST</p>
        <div className="flex items-end gap-[2px] h-3">
          {Array.from({ length: 10 }).map((_, i) => (
            <span
              key={i}
              className="w-[2.5px] rounded-sm"
              style={{
                height: `${(i + 1) * 10}%`,
                background: i < Math.round(interest / 10) ? "#38BDF8" : "rgba(94,182,245,0.18)",
              }}
            />
          ))}
          <span className="text-[10px] ml-1" style={{ ...mono, color: "#5EB6F5" }}>{interest}%</span>
        </div>
      </div>

      <span
        className="absolute top-3 right-3 h-7 w-7 rounded-md flex items-center justify-center transition-colors"
        style={{ background: "rgba(94,182,245,0.1)", border: "1px solid rgba(94,182,245,0.25)", color: hovered ? "#7DD3FC" : "#5B7CA3" }}
      >
        <ArrowUpRight size={14} />
      </span>
    </div>
  );
}

function EventCard({ e, icon }) {
  const [hovered, setHovered] = useState(false);
  const statusColor =
    e.status === "OPEN" ? "#7DD3FC" : e.status === "REGISTER_NOW" ? "#5EEAD4" : "#7C93B4";

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className="relative flex-shrink-0 w-72 sm:w-80 snap-center rounded-xl overflow-hidden transition-all duration-300"
      style={{
        background: "#050E22",
        border: `1px solid ${hovered ? "rgba(125,211,252,0.55)" : "rgba(94,182,245,0.18)"}`,
        boxShadow: hovered
          ? "0 0 0 1px rgba(94,182,245,0.15), 0 24px 48px rgba(30,155,240,0.22)"
          : "0 12px 28px rgba(0,0,0,0.35)",
        transform: hovered ? "translateY(-6px)" : "translateY(0)",
      }}
    >
      <EventVisual hovered={hovered} icon={icon} interest={e.interest} />

      <div className="p-5">
        <div className="flex items-center gap-2 mb-3">
          <span className="h-1.5 w-1.5 rounded-full" style={{ background: statusColor }} />
          <span className="text-[11px]" style={{ ...mono, color: "#5B7CA3" }}>{e.id}</span>
        </div>

        <h3 className="font-semibold text-lg leading-snug mb-4" style={{ ...display, color: "#F1F5F9" }}>
          {e.title}
        </h3>

        <div
          className="grid grid-cols-2 gap-x-3 gap-y-2 text-[12px] pb-4 mb-4"
          style={{ ...mono, borderBottom: "1px solid rgba(94,182,245,0.14)" }}
        >
          <div>
            <p style={{ color: "#5B7CA3" }}>DATE</p>
            <p style={{ color: "#DCEBFB" }}>{e.date}</p>
          </div>
          <div>
            <p style={{ color: "#5B7CA3" }}>TYPE</p>
            <p style={{ color: "#DCEBFB" }}>{e.type}</p>
          </div>
          <div>
            <p style={{ color: "#5B7CA3" }}>LOCATION</p>
            <p style={{ color: "#DCEBFB" }}>{e.location}</p>
          </div>
          <div>
            <p style={{ color: "#5B7CA3" }}>STATUS</p>
            <p style={{ color: statusColor }}>{e.status}</p>
          </div>
        </div>

        <p
          className="text-sm font-medium flex items-center gap-1.5 transition-all duration-200"
          style={{ ...display, color: hovered ? "#7DD3FC" : "#38BDF8", gap: hovered ? "10px" : "6px" }}
        >
          Explore <ArrowRight size={15} />
          {hovered && <BlinkingCursor color="#7DD3FC" width={6} height={13} className="ml-0.5" />}
        </p>
      </div>
    </div>
  );
}

function Events() {
  const { trackRef, onPointerDown, onPointerMove, onPointerUp, onWheel, scrollByAmount } = useHorizontalScroll();

  return (
    <section id="events" className="py-28" style={{ background: "#050E22" }}>
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-4">
          <div>
            <Reveal>
              <p className="text-sky-400 font-semibold text-sm mb-3" style={mono}>$ comsoc events --upcoming</p>
            </Reveal>
            <Reveal delay={60}>
              <h2 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight" style={heading}>
                Upcoming events
              </h2>
            </Reveal>
          </div>
          <Reveal delay={120}>
            <div className="hidden sm:flex items-center gap-3">
              <ScrollArrow direction="left" onClick={() => scrollByAmount(-330)} />
              <ScrollArrow direction="right" onClick={() => scrollByAmount(330)} />
            </div>
          </Reveal>
        </div>

        <Reveal delay={160}>
          <div
            ref={trackRef}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerLeave={onPointerUp}
            onWheel={onWheel}
            className="flex gap-6 overflow-x-auto pb-6 pt-10 -mx-6 px-6 cursor-grab active:cursor-grabbing snap-x snap-mandatory"
            style={{ scrollbarWidth: "none" }}
          >
            {events.map((e, i) => (
              <EventCard key={e.id} e={e} icon={EVENT_ICONS[i % EVENT_ICONS.length]} />
            ))}
          </div>
        </Reveal>

        <Reveal delay={200}>
          <div className="mt-4 text-center">
            <button
              className="inline-flex items-center gap-2 font-semibold hover:opacity-80 transition-opacity"
              style={{ ...mono, color: "#38BDF8" }}
            >
              $ view --all-events <ChevronRight size={16} />
            </button>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default Events;
