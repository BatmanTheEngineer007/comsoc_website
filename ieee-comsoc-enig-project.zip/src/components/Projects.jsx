import React from "react";
import { Github, ArrowRight, Cpu } from "lucide-react";
import { Reveal } from "./shared";
import { projects } from "../data";
import { heading, body } from "../lib/theme";

function Projects() {
  return (
    <section id="projects" className="bg-slate-50 py-28">
      <div className="max-w-7xl mx-auto px-6">
        <Reveal>
          <p className="text-blue-600 font-semibold text-sm mb-3" style={body}>Built by our members</p>
        </Reveal>
        <Reveal delay={60}>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-blue-950 tracking-tight max-w-xl" style={heading}>
            Student innovation
          </h2>
        </Reveal>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {projects.map((p, i) => (
            <Reveal key={p.title} delay={(i % 3) * 100}>
              <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden h-full flex flex-col hover:shadow-xl hover:shadow-blue-100/70 hover:-translate-y-1 transition-all duration-300">
                <div className="h-32 flex items-center justify-center" style={{ background: "linear-gradient(135deg,#10265B,#0B3D91)" }}>
                  <Cpu className="text-sky-300/70" size={34} />
                </div>
                <div className="p-6 flex flex-col flex-1">
                  <h3 className="font-bold text-lg text-blue-950 mb-2" style={heading}>{p.title}</h3>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {p.tags.map((t) => (
                      <span key={t} className="text-xs font-medium text-blue-700 bg-blue-50 px-2.5 py-1 rounded-full" style={body}>
                        {t}
                      </span>
                    ))}
                  </div>
                  <p className="text-slate-600 text-sm leading-relaxed flex-1" style={body}>{p.desc}</p>
                  <div className="flex items-center gap-4 mt-5">
                    <button className="inline-flex items-center gap-1.5 text-slate-700 font-semibold text-sm hover:text-blue-900" style={body}>
                      <Github size={15} /> GitHub
                    </button>
                    <button className="inline-flex items-center gap-1.5 text-blue-700 font-semibold text-sm hover:text-blue-900" style={body}>
                      Explore project <ArrowRight size={14} />
                    </button>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Projects;
