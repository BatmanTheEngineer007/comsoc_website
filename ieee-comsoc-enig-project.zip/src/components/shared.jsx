import React, { useEffect, useRef, useState } from "react";
import { ChevronRight } from "lucide-react";

function useReveal() {
  const ref = useRef(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          io.disconnect();
        }
      },
      { threshold: 0.15 }
    );
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return [ref, visible];
}

function Reveal({ children, delay = 0, className = "" }) {
  const [ref, visible] = useReveal();
  return (
    <div
      ref={ref}
      className={className}
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(24px)",
        transition: `opacity 0.7s ease ${delay}ms, transform 0.7s ease ${delay}ms`,
      }}
    >
      {children}
    </div>
  );
}

function NetworkBackground({ opacity = 0.35, dark = true }) {
  const nodes = [
    [60, 80], [220, 40], [380, 120], [520, 60], [680, 140],
    [140, 220], [320, 260], [480, 220], [640, 280], [90, 340],
    [260, 380], [440, 360], [600, 400], [740, 320], [40, 420],
  ];
  const edges = [
    [0, 1], [1, 2], [2, 3], [3, 4], [1, 5], [5, 6], [6, 2], [6, 7],
    [7, 3], [7, 8], [8, 4], [5, 9], [9, 10], [10, 6], [10, 11],
    [11, 7], [11, 12], [12, 8], [12, 13], [9, 14], [14, 10],
  ];
  const stroke = dark ? "#5EB6F5" : "#1E5FA8";
  const dot = dark ? "#7CC8FF" : "#0B3D91";
  return (
    <svg
      viewBox="0 0 800 460"
      preserveAspectRatio="xMidYMid slice"
      className="absolute inset-0 w-full h-full"
      style={{ opacity }}
      aria-hidden="true"
    >
      {edges.map(([a, b], i) => (
        <line
          key={i}
          x1={nodes[a][0]} y1={nodes[a][1]}
          x2={nodes[b][0]} y2={nodes[b][1]}
          stroke={stroke}
          strokeWidth="1"
        >
          <animate
            attributeName="stroke-opacity"
            values="0.15;0.6;0.15"
            dur={`${5 + (i % 5)}s`}
            repeatCount="indefinite"
            begin={`${i * 0.3}s`}
          />
        </line>
      ))}
      {nodes.map(([x, y], i) => (
        <circle key={i} cx={x} cy={y} r={i % 3 === 0 ? 4 : 2.5} fill={dot}>
          <animate
            attributeName="opacity"
            values="0.4;1;0.4"
            dur={`${3 + (i % 4)}s`}
            repeatCount="indefinite"
            begin={`${i * 0.2}s`}
          />
        </circle>
      ))}
    </svg>
  );
}

function useHorizontalScroll() {
  const trackRef = useRef(null);
  const drag = useRef({ active: false, startX: 0, startScroll: 0 });

  const onPointerDown = (e) => {
    const el = trackRef.current;
    if (!el) return;
    drag.current = { active: true, startX: e.clientX, startScroll: el.scrollLeft };
    el.setPointerCapture?.(e.pointerId);
  };
  const onPointerMove = (e) => {
    if (!drag.current.active || !trackRef.current) return;
    trackRef.current.scrollLeft = drag.current.startScroll - (e.clientX - drag.current.startX);
  };
  const onPointerUp = () => {
    drag.current.active = false;
  };
  const onWheel = (e) => {
    const el = trackRef.current;
    if (!el) return;
    if (Math.abs(e.deltaY) > Math.abs(e.deltaX)) {
      el.scrollLeft += e.deltaY;
      e.preventDefault();
    }
  };
  const scrollByAmount = (amount) => {
    trackRef.current?.scrollBy({ left: amount, behavior: "smooth" });
  };

  return { trackRef, onPointerDown, onPointerMove, onPointerUp, onWheel, scrollByAmount };
}

function ScrollArrow({ direction, onClick }) {
  return (
    <button
      onClick={onClick}
      aria-label={direction === "left" ? "Scroll left" : "Scroll right"}
      className="h-11 w-11 rounded-full flex items-center justify-center text-white hover:text-blue-950 hover:bg-sky-300 transition-colors flex-shrink-0"
      style={{ background: "rgba(255,255,255,0.08)", border: "1px solid rgba(255,255,255,0.18)" }}
    >
      <ChevronRight size={18} style={{ transform: direction === "left" ? "rotate(180deg)" : "none" }} />
    </button>
  );
}

function BlinkingCursor({ color = "#7DD3FC", height = 16, width = 9, className = "ml-1" }) {
  return (
    <span
      className={`inline-block align-middle ${className}`}
      style={{ width, height, background: color, animation: "comsoc-blink 1s step-end infinite" }}
    />
  );
}

export { useReveal, Reveal, NetworkBackground, useHorizontalScroll, ScrollArrow, BlinkingCursor };
