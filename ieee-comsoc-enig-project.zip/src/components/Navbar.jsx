import React, { useEffect, useState } from "react";
import { Menu, X, Radio } from "lucide-react";
import { NAV_LINKS } from "../data";
import { heading, body } from "../lib/theme";

function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const handleClick = (href) => {
    setOpen(false);
    const el = document.querySelector(href);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <header
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        backdropFilter: "blur(14px)",
        WebkitBackdropFilter: "blur(14px)",
        background: scrolled ? "rgba(6, 18, 41, 0.88)" : "rgba(6, 18, 41, 0.35)",
        borderBottom: scrolled ? "1px solid rgba(94,182,245,0.18)" : "1px solid transparent",
      }}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between h-16">
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5">
            <div className="h-8 w-8 rounded-md bg-blue-600 flex items-center justify-center text-white text-xs font-bold" style={heading}>
              IEEE
            </div>
            <div className="h-8 w-8 rounded-md flex items-center justify-center text-white" style={{ background: "linear-gradient(135deg,#1E9BF0,#0B3D91)" }}>
              <Radio size={16} />
            </div>
          </div>
          <span className="text-white font-semibold text-[15px] tracking-tight" style={heading}>
            IEEE ComSoc ENIG
          </span>
        </div>

        <nav className="hidden lg:flex items-center gap-8">
          {NAV_LINKS.map((l) => (
            <button
              key={l.href}
              onClick={() => handleClick(l.href)}
              className="text-sm text-blue-100/80 hover:text-white transition-colors"
              style={body}
            >
              {l.label}
            </button>
          ))}
        </nav>

        <div className="flex items-center gap-3">
          <button
            onClick={() => handleClick("#join")}
            className="hidden sm:inline-flex items-center gap-1.5 bg-sky-400 hover:bg-sky-300 text-blue-950 font-semibold text-sm px-5 py-2.5 rounded-full transition-all active:scale-95"
            style={body}
          >
            Join Us
          </button>
          <button
            className="lg:hidden text-white p-2"
            onClick={() => setOpen((o) => !o)}
            aria-label="Toggle menu"
          >
            {open ? <X size={22} /> : <Menu size={22} />}
          </button>
        </div>
      </div>

      <div
        className="lg:hidden overflow-hidden transition-all duration-300"
        style={{
          maxHeight: open ? "480px" : "0px",
          background: "rgba(6, 18, 41, 0.97)",
        }}
      >
        <div className="flex flex-col px-6 py-4 gap-1">
          {NAV_LINKS.map((l) => (
            <button
              key={l.href}
              onClick={() => handleClick(l.href)}
              className="text-left text-blue-100/85 hover:text-white py-2.5 text-sm border-b border-white/5"
              style={body}
            >
              {l.label}
            </button>
          ))}
          <button
            onClick={() => handleClick("#join")}
            className="mt-3 bg-sky-400 text-blue-950 font-semibold text-sm px-5 py-2.5 rounded-full"
            style={body}
          >
            Join Us
          </button>
        </div>
      </div>
    </header>
  );
}

export default Navbar;
