import React from "react";
import { ArrowRight } from "lucide-react";
import { Reveal } from "./shared";
import { news } from "../data";
import { heading, body, mono } from "../lib/theme";

function News() {
  return (
    <section id="news" className="bg-white py-28">
      <div className="max-w-7xl mx-auto px-6">
        <Reveal>
          <p className="text-blue-600 font-semibold text-sm mb-3" style={body}>Stay in the loop</p>
        </Reveal>
        <Reveal delay={60}>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-blue-950 tracking-tight max-w-xl" style={heading}>
            Latest from ComSoc ENIG
          </h2>
        </Reveal>

        <div className="mt-14 grid sm:grid-cols-2 gap-6">
          {news.map((n, i) => (
            <Reveal key={n.title} delay={i * 90}>
              <div className="border border-slate-200 rounded-2xl p-7 h-full hover:border-blue-300 hover:shadow-lg hover:shadow-blue-100 transition-all duration-300">
                <div className="flex items-center gap-3 text-xs text-slate-500 mb-4" style={body}>
                  <span>{n.date}</span>
                  <span className="h-1 w-1 rounded-full bg-slate-300" />
                  <span className="text-blue-700 font-semibold">{n.category}</span>
                </div>
                <h3 className="font-bold text-lg text-blue-950 mb-2" style={heading}>{n.title}</h3>
                <p className="text-slate-600 text-[15px] leading-relaxed mb-5" style={body}>{n.excerpt}</p>
                <button className="inline-flex items-center gap-1.5 text-blue-700 font-semibold text-sm hover:gap-2.5 transition-all" style={body}>
                  Read more <ArrowRight size={14} />
                </button>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export default News;
