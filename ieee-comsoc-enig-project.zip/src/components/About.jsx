import React from "react";
import { Radio, Users, Lightbulb } from "lucide-react";
import { Reveal } from "./shared";
import { aboutCards } from "../data";
import { heading, body } from "../lib/theme";

function About() {
  return (
    <section id="about" className="bg-white py-28">
      <div className="max-w-7xl mx-auto px-6">
        <Reveal>
          <p className="text-blue-600 font-semibold text-sm mb-3" style={body}>About the chapter</p>
        </Reveal>
        <Reveal delay={60}>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-blue-950 tracking-tight max-w-2xl" style={heading}>
            Who we are
          </h2>
        </Reveal>
        <Reveal delay={120}>
          <p className="mt-6 text-slate-600 max-w-2xl text-[17px] leading-relaxed" style={body}>
            IEEE ComSoc ENIG is a student chapter dedicated to bringing students together around
            communications and networking technologies. We build a space where curiosity about how
            the world connects turns into real technical skill, lasting friendships, and a bridge
            into the wider IEEE Communications Society community.
          </p>
        </Reveal>

        <div className="mt-16 grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {aboutCards.map((c, i) => (
            <Reveal key={c.title} delay={i * 100}>
              <div className="group border border-slate-200 rounded-2xl p-8 h-full hover:border-blue-300 hover:shadow-lg hover:shadow-blue-100 transition-all duration-300 hover:-translate-y-1">
                <div className="h-12 w-12 rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-6 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <c.icon size={22} />
                </div>
                <h3 className="text-xl font-bold text-blue-950 mb-2" style={heading}>{c.title}</h3>
                <p className="text-slate-600 text-[15px] leading-relaxed" style={body}>{c.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export default About;
