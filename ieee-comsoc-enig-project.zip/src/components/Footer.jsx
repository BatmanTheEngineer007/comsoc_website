import React from "react";
import { Linkedin, Mail, Instagram, Facebook } from "lucide-react";
import { NAV_LINKS, CONTACT, SOCIAL_LINKS } from "../data";
import { heading, body } from "../lib/theme";

function Footer() {
  const socials = [
    { icon: Linkedin, label: "LinkedIn", href: SOCIAL_LINKS.linkedin },
    { icon: Instagram, label: "Instagram", href: SOCIAL_LINKS.instagram },
    { icon: Facebook, label: "Facebook", href: SOCIAL_LINKS.facebook },
    { icon: Mail, label: "Email", href: `mailto:${CONTACT.email}` },
  ];
  return (
    <footer id="contact" style={{ background: "#050E22" }} className="pt-20 pb-10">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-12">
          <div>
            <div className="flex items-center gap-2 mb-4">
              <div className="h-8 w-8 rounded-md bg-blue-600 flex items-center justify-center text-white text-xs font-bold" style={heading}>IEEE</div>
              <span className="text-white font-semibold text-sm" style={heading}>ComSoc ENIG</span>
            </div>
            <p className="text-blue-200/50 text-sm leading-relaxed" style={body}>
              The IEEE Communications Society Student Branch Chapter at ENIG — connecting students
              through communications and networking technology.
            </p>
          </div>

          <div>
            <h4 className="text-white font-semibold text-sm mb-4" style={heading}>Quick links</h4>
            <ul className="space-y-2.5">
              {NAV_LINKS.slice(1, 5).map((l) => (
                <li key={l.href}>
                  <a href={l.href} className="text-blue-200/60 hover:text-white text-sm transition-colors" style={body}>
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold text-sm mb-4" style={heading}>Explore</h4>
            <ul className="space-y-2.5">
              <li><a href="#events" className="text-blue-200/60 hover:text-white text-sm transition-colors" style={body}>Events</a></li>
              <li><a href="#projects" className="text-blue-200/60 hover:text-white text-sm transition-colors" style={body}>Projects</a></li>
              <li><a href="#news" className="text-blue-200/60 hover:text-white text-sm transition-colors" style={body}>Resources</a></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-semibold text-sm mb-4" style={heading}>Contact</h4>
            <p className="text-blue-200/60 text-sm mb-1" style={body}>{CONTACT.address}</p>
            <p className="text-blue-200/60 text-sm mb-5" style={body}>{CONTACT.email}</p>
            <div className="flex items-center gap-3">
              {socials.map((s) => (
                <a
                  key={s.label}
                  href={s.href}
                  target={s.href.startsWith("mailto:") ? undefined : "_blank"}
                  rel={s.href.startsWith("mailto:") ? undefined : "noreferrer"}
                  aria-label={s.label}
                  className="h-9 w-9 rounded-full flex items-center justify-center text-blue-200/70 hover:text-white transition-colors"
                  style={{ background: "rgba(255,255,255,0.06)" }}
                >
                  <s.icon size={15} />
                </a>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-3">
          <p className="text-blue-200/40 text-xs" style={body}>
            © 2026 IEEE Communications Society ENIG Student Branch Chapter
          </p>
          <p className="text-blue-200/40 text-xs" style={body}>
            IEEE &bull; IEEE Communications Society &bull; ENIG
          </p>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
