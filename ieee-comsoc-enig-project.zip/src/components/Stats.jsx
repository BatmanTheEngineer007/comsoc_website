import React, { useEffect, useState } from "react";
import { useReveal, NetworkBackground } from "./shared";
import { stats } from "../data";
import { heading, body } from "../lib/theme";

function Counter({ target, suffix }) {
  const [ref, visible] = useReveal();
  const [value, setValue] = useState(0);

  useEffect(() => {
    if (!visible) return;
    let frame;
    const duration = 1400;
    const start = performance.now();
    const tick = (now) => {
      const progress = Math.min((now - start) / duration, 1);
      setValue(Math.round(target * (1 - Math.pow(1 - progress, 3))));
      if (progress < 1) frame = requestAnimationFrame(tick);
    };
    frame = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(frame);
  }, [visible, target]);

  return (
    <div ref={ref} className="text-5xl sm:text-6xl font-extrabold text-white" style={heading}>
      {value}{suffix}
    </div>
  );
}

function Stats() {
  return (
    <section className="relative py-24 overflow-hidden" style={{ background: "#061229" }}>
      <NetworkBackground opacity={0.22} />
      <div className="relative max-w-6xl mx-auto px-6 grid grid-cols-2 lg:grid-cols-4 gap-10 text-center">
        {stats.map((s) => (
          <div key={s.label}>
            <Counter target={s.value} suffix={s.suffix} />
            <p className="text-blue-200/70 mt-2 text-sm font-medium" style={body}>{s.label}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

export default Stats;
