import React from "react";
import { Radio, ExternalLink } from "lucide-react";
import { Reveal } from "./shared";
import { heading, body } from "../lib/theme";

function IEEEConnection() {
  return (
    <section className="bg-slate-50 py-24">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <Reveal>
          <div className="flex items-center justify-center gap-4 mb-8">
            <div className="h-14 w-14 rounded-xl bg-blue-600 flex items-center justify-center text-white font-bold text-sm" style={heading}>
              IEEE
            </div>
            <div className="h-14 w-14 rounded-xl flex items-center justify-center text-white" style={{ background: "linear-gradient(135deg,#1E9BF0,#0B3D91)" }}>
              <Radio size={24} />
            </div>
          </div>
        </Reveal>
        <Reveal delay={80}>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-blue-950 tracking-tight" style={heading}>
            Part of a global network
          </h2>
        </Reveal>
        <Reveal delay={140}>
          <p className="mt-5 text-slate-600 text-[17px] leading-relaxed max-w-2xl mx-auto" style={body}>
            As a Student Branch Chapter of the IEEE Communications Society, ENIG's chapter connects
            local students to a worldwide community of engineers and researchers advancing the
            science of communications — access to publications, conferences, and mentorship included.
          </p>
        </Reveal>
        <Reveal delay={200}>
          <a
            href="https://www.comsoc.org/about"
            target="_blank"
            rel="noreferrer"
            className="mt-8 inline-flex items-center gap-2 bg-blue-700 hover:bg-blue-800 text-white font-semibold px-7 py-3.5 rounded-full transition-colors"
            style={body}
          >
            Visit IEEE ComSoc <ExternalLink size={16} />
          </a>
        </Reveal>
      </div>
    </section>
  );
}

export default IEEEConnection;
