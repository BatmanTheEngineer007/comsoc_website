import React, { useState } from "react";
import { Linkedin, Mail } from "lucide-react";
import { Reveal, NetworkBackground, useHorizontalScroll, ScrollArrow } from "./shared";
import { boardMembers } from "../data";
import { heading, body } from "../lib/theme";

function BoardCard({ member, featured }) {
  const [hovered, setHovered] = useState(false);
  const initials = member.name.split(" ").map((n) => n[0]).slice(0, 2).join("");

  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      className={`relative rounded-3xl flex-shrink-0 snap-center flex flex-col justify-between transition-transform duration-300 ${featured ? "w-72 sm:w-80 p-9" : "w-64 sm:w-72 p-8"}`}
      style={{
        background: hovered
          ? "linear-gradient(155deg, rgba(255,255,255,0.2), rgba(255,255,255,0.07))"
          : "linear-gradient(155deg, rgba(255,255,255,0.14), rgba(255,255,255,0.05))",
        backdropFilter: "blur(28px) saturate(160%)",
        WebkitBackdropFilter: "blur(28px) saturate(160%)",
        border: `1px solid ${hovered ? "rgba(191,225,254,0.45)" : "rgba(255,255,255,0.22)"}`,
        boxShadow: hovered
          ? "0 1px 0 rgba(255,255,255,0.3) inset, 0 0 0 1px rgba(125,211,252,0.25), 0 20px 44px rgba(56,189,248,0.24)"
          : "0 1px 0 rgba(255,255,255,0.25) inset, 0 12px 32px rgba(2,10,28,0.35)",
        transform: hovered ? "translateY(-6px)" : "translateY(0)",
      }}
    >
      <div>
        <div
          className={`${featured ? "h-24 w-24 text-2xl" : "h-20 w-20 text-lg"} rounded-full flex items-center justify-center text-white font-bold mb-6 transition-transform duration-300`}
          style={{
            background: "linear-gradient(135deg,#1E9BF0,#0B3D91)",
            transform: hovered ? "scale(1.08)" : "scale(1)",
            ...heading,
          }}
        >
          {initials}
        </div>
        <h4 className={`text-white font-bold ${featured ? "text-2xl" : "text-lg"}`} style={heading}>
          {member.name}
        </h4>
        <p className="text-sky-300 text-sm font-medium mt-1" style={body}>{member.role}</p>
        <p className={`text-blue-50/80 mt-4 leading-relaxed ${featured ? "text-[15px]" : "text-sm"}`} style={body}>
          {member.bio}
        </p>
      </div>
      <div
        className="flex items-center gap-3 mt-6 transition-opacity duration-300"
        style={{ opacity: hovered ? 1 : 0.55 }}
      >
        <a href="#" aria-label={`${member.name} on LinkedIn`} className="h-9 w-9 rounded-full flex items-center justify-center text-blue-100 hover:text-white transition-colors" style={{ background: "rgba(255,255,255,0.1)" }}>
          <Linkedin size={15} />
        </a>
        <a href="#" aria-label={`Email ${member.name}`} className="h-9 w-9 rounded-full flex items-center justify-center text-blue-100 hover:text-white transition-colors" style={{ background: "rgba(255,255,255,0.1)" }}>
          <Mail size={15} />
        </a>
      </div>
    </div>
  );
}

function Board() {
  const { trackRef, onPointerDown, onPointerMove, onPointerUp, onWheel, scrollByAmount } = useHorizontalScroll();

  return (
    <section id="board" className="relative py-28 overflow-hidden" style={{ background: "linear-gradient(180deg,#050E22,#0A1E42)" }}>
      <NetworkBackground opacity={0.16} />
      <div className="relative max-w-7xl mx-auto px-6">
        <div className="flex flex-wrap items-end justify-between gap-6 mb-4">
          <div>
            <Reveal>
              <h2 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight" style={heading}>
                Meet our board
              </h2>
            </Reveal>
            <Reveal delay={80}>
              <p className="text-blue-200/60 mt-4" style={body}>
                The people driving our chapter forward.
              </p>
            </Reveal>
          </div>
          <Reveal delay={120}>
            <div className="hidden sm:flex items-center gap-3">
              <ScrollArrow direction="left" onClick={() => scrollByAmount(-320)} />
              <ScrollArrow direction="right" onClick={() => scrollByAmount(320)} />
            </div>
          </Reveal>
        </div>

        <Reveal delay={160}>
          <div
            ref={trackRef}
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerLeave={onPointerUp}
            onWheel={onWheel}
            className="flex gap-6 overflow-x-auto pb-6 pt-10 -mx-6 px-6 cursor-grab active:cursor-grabbing snap-x snap-mandatory"
            style={{ scrollbarWidth: "none" }}
          >
            {boardMembers.map((m, i) => (
              <BoardCard key={m.name} member={m} featured={i === 0} />
            ))}
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default Board;
