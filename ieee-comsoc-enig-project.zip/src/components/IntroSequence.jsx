import React, { useState, useEffect, useRef, useCallback } from "react";
import { NetworkBackground, BlinkingCursor } from "./shared";
import { INTRO_COMMANDS } from "../data";
import { mono, display } from "../lib/theme";

function useTypedLine(text, active, speed = 18) {
  const [out, setOut] = useState("");
  useEffect(() => {
    if (!active) {
      setOut("");
      return;
    }
    let i = 0;
    setOut("");
    const id = setInterval(() => {
      i += 1;
      setOut(text.slice(0, i));
      if (i >= text.length) clearInterval(id);
    }, speed);
    return () => clearInterval(id);
  }, [text, active, speed]);
  return out;
}

function IntroTerminalLine({ command, active, done }) {
  const typed = useTypedLine(command, active);
  return (
    <p className="text-[13px] sm:text-sm" style={{ ...mono, color: done ? "#5EEAD4" : "#7DD3FC", minHeight: 20 }}>
      {done ? "\u2713 " : ""}
      {done ? command.replace(/^[$>]\s*/, "").replace(/\.\.\.$/, " established") : typed}
      {active && !done && <BlinkingCursor color="#7DD3FC" width={7} height={14} />}
    </p>
  );
}

function IntroSatellite({ phase }) {
  // phase: scan | signal | handshake | connected
  const waveCount = phase === "connected" ? 3 : phase === "handshake" ? 2 : 1;
  const orbitSpeed = phase === "handshake" ? "1.1s" : phase === "connected" ? "0.9s" : "2.4s";
  return (
    <svg viewBox="0 0 200 200" className="w-40 h-40 sm:w-48 sm:h-48 mx-auto mb-6" aria-hidden="true">
      <circle cx="100" cy="100" r="76" fill="none" stroke="#153E75" strokeWidth="1" />
      <circle cx="100" cy="100" r="4" fill={phase === "connected" ? "#5EEAD4" : "#38BDF8"}>
        {phase === "connected" && (
          <animate attributeName="r" values="4;7;4" dur="0.8s" repeatCount="indefinite" />
        )}
      </circle>
      {Array.from({ length: waveCount }).map((_, i) => (
        <circle key={i} cx="100" cy="100" r="4" fill="none" stroke="#38BDF8" strokeWidth="1">
          <animate attributeName="r" values="4;80" dur="2s" begin={`${i * (2 / waveCount)}s`} repeatCount="indefinite" />
          <animate attributeName="opacity" values="0.6;0" dur="2s" begin={`${i * (2 / waveCount)}s`} repeatCount="indefinite" />
        </circle>
      ))}
      <circle r="4.5" fill="#7DD3FC">
        <animateMotion dur={orbitSpeed} repeatCount="indefinite" path="M 100 24 A 76 76 0 1 1 99.99 24" />
      </circle>
      <line x1="100" y1="100" x2="100" y2="24" stroke="#38BDF8" strokeWidth="1" opacity="0.5">
        <animate attributeName="opacity" values="0;0.8;0" dur="1.2s" repeatCount="indefinite" />
      </line>
    </svg>
  );
}

function IntroSequence({ onDone }) {
  const [now, setNow] = useState(0);
  const [stage, setStage] = useState("commands"); // commands | connected | leaving
  const [progress, setProgress] = useState(0);
  const [skipped, setSkipped] = useState(false);
  const startRef = useRef(null);
  const reducedMotion = useRef(
    typeof window !== "undefined" && window.matchMedia?.("(prefers-reduced-motion: reduce)").matches
  );

  const finish = useCallback(() => {
    try {
      sessionStorage.setItem("comsoc_intro_done", "1");
    } catch (e) {}
    onDone();
  }, [onDone]);

  useEffect(() => {
    if (reducedMotion.current) {
      const t = setTimeout(finish, 500);
      return () => clearTimeout(t);
    }
    let raf;
    startRef.current = performance.now();
    const tick = (t) => {
      const elapsed = t - startRef.current;
      setNow(elapsed);
      setProgress(Math.min(100, Math.round((elapsed / 4300) * 100)));
      if (elapsed < 4900) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);

    const timers = [];
    timers.push(setTimeout(() => setStage("connected"), 4350));
    timers.push(setTimeout(() => setStage("leaving"), 4300 + 700));
    timers.push(setTimeout(finish, 4300 + 700 + 700));
    return () => {
      cancelAnimationFrame(raf);
      timers.forEach(clearTimeout);
    };
  }, [finish]);

  const handleSkip = () => {
    setSkipped(true);
    finish();
  };

  const activeIndex = INTRO_COMMANDS.findIndex((c) => now >= c.at && now < c.done + 400);
  const phase =
    now < 800 ? "scan" : now < 2250 ? "signal" : now < 3800 ? "handshake" : "connected";

  return (
    <div
      className="fixed inset-0 z-[999] flex items-center justify-center overflow-hidden transition-all duration-700"
      style={{
        background: "#050E22",
        opacity: stage === "leaving" ? 0 : 1,
        transform: stage === "leaving" ? "scale(1.06)" : "scale(1)",
        pointerEvents: skipped ? "none" : "auto",
      }}
    >
      <NetworkBackground opacity={0.28} />

      <div className="relative w-full max-w-md px-6 text-center">
        {stage !== "connected" && stage !== "leaving" && (
          <>
            <p className="text-sm sm:text-base font-medium tracking-tight mb-5" style={{ ...display, color: "#EAF3FC" }}>
              Establishing connection
            </p>
            <IntroSatellite phase={phase} />
            <div className="text-left mx-auto max-w-xs space-y-1">
              {INTRO_COMMANDS.map((c, i) => {
                if (now < c.at - 50) return null;
                const active = i === activeIndex;
                const isDone = now >= c.done;
                return <IntroTerminalLine key={c.cmd} command={c.cmd} active={active || (now >= c.at && !isDone)} done={isDone} />;
              })}
            </div>
            <div className="mt-6 flex items-center gap-3 mx-auto max-w-xs">
              <div className="flex-1 h-1.5 rounded-full overflow-hidden" style={{ background: "rgba(94,182,245,0.15)" }}>
                <div
                  className="h-full rounded-full"
                  style={{ width: `${progress}%`, background: "linear-gradient(90deg,#0B3D91,#38BDF8)", transition: "width 0.1s linear" }}
                />
              </div>
              <span className="text-sm font-medium tabular-nums" style={{ ...display, color: "#7DD3FC", minWidth: 34 }}>
                {progress}%
              </span>
            </div>
          </>
        )}

        {(stage === "connected" || stage === "leaving") && (
          <div>
            <IntroSatellite phase="connected" />
            <p className="text-2xl sm:text-3xl font-semibold tracking-tight text-white" style={display}>
              &#10003; Connection established
            </p>
            <p className="text-base sm:text-lg mt-2" style={{ ...display, color: "#7DD3FC" }}>
              IEEE ComSoc &times; ENIG
            </p>
          </div>
        )}
      </div>

      <button
        onClick={handleSkip}
        className="absolute bottom-6 right-6 text-xs px-4 py-2 rounded-full transition-colors"
        style={{ ...mono, color: "#7C93B4", background: "rgba(255,255,255,0.06)", border: "1px solid rgba(94,182,245,0.2)" }}
      >
        Skip &rarr;
      </button>
    </div>
  );
}

export default IntroSequence;
