import React from "react";
import { Reveal } from "./shared";
import { activities } from "../data";
import { heading, body } from "../lib/theme";

function Activities() {
  return (
    <section id="activities" className="bg-white py-28">
      <div className="max-w-7xl mx-auto px-6">
        <Reveal>
          <p className="text-blue-600 font-semibold text-sm mb-3" style={body}>How we grow</p>
        </Reveal>
        <Reveal delay={60}>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-blue-950 tracking-tight max-w-xl" style={heading}>
            Chapter activities
          </h2>
        </Reveal>

        <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-5">
          {activities.map((a, i) => (
            <Reveal key={a.title} delay={i * 60}>
              <div className="group border border-slate-200 rounded-2xl p-7 text-center hover:border-blue-300 hover:bg-blue-50/50 transition-all duration-300 hover:-translate-y-1">
                <div className="h-12 w-12 mx-auto rounded-xl bg-blue-50 text-blue-700 flex items-center justify-center mb-4 group-hover:bg-blue-600 group-hover:text-white transition-colors">
                  <a.icon size={20} />
                </div>
                <p className="font-semibold text-blue-950 text-[15px]" style={heading}>{a.title}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export default Activities;
