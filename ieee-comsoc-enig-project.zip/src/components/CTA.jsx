import React from "react";
import { ArrowRight } from "lucide-react";
import { Reveal, NetworkBackground } from "./shared";
import { heading, body } from "../lib/theme";

function CTA() {
  return (
    <section id="join" className="relative py-28 overflow-hidden" style={{ background: "linear-gradient(160deg,#0A1F45,#0B3D91)" }}>
      <NetworkBackground opacity={0.3} />
      <div className="relative max-w-3xl mx-auto px-6 text-center">
        <Reveal>
          <h2 className="text-4xl sm:text-5xl font-extrabold text-white tracking-tight" style={heading}>
            Be part of the network.
          </h2>
        </Reveal>
        <Reveal delay={80}>
          <p className="mt-5 text-blue-100/80 text-lg" style={body}>
            Learn. Connect. Innovate. Build the future of communications with us.
          </p>
        </Reveal>
        <Reveal delay={160}>
          <div className="mt-9 flex flex-wrap justify-center gap-4">
            <button className="inline-flex items-center gap-2 bg-sky-400 hover:bg-sky-300 text-blue-950 font-semibold px-7 py-3.5 rounded-full transition-all active:scale-95" style={body}>
              Join our chapter <ArrowRight size={17} />
            </button>
            <a href="#contact" className="inline-flex items-center gap-2 border border-white/25 hover:border-white/50 text-white px-7 py-3.5 rounded-full transition-colors" style={body}>
              Contact us
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export default CTA;
